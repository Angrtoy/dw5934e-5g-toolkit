这些是工程参考，不能切片。front_bezel_reference.step 不含最终 front_bezel.stl 的网格并入压脚。
