# Source revision 2491007 (read-only intake)

- Claimed source page: https://makerworld.com.cn/zh/models/2491007-a-le-qia-mf650wai-ke-xiu-gai-ban?from=search#profileId-2849695
- User-provided archive path resolved on disk as `C:\Users\19570\Downloads\底壳_stls.zip` (the Downloads folder contains this file; no literal `底壳\_stls.zip` path exists).
- Original archive copied unchanged as `底壳_stls.zip`; extracted models are under `models/`.
- ZIP safety: 3 regular STL entries, no absolute/`..` paths, total uncompressed 2,131,352 bytes, no suspicious size/ratio, no scripts/executables. SHA-256 and entry CRCs are in `new_source_report.json`.
- STL has no unit or assembly metadata. Dimensions below are interpreted as mm only by comparison with the known old STEP dimensions; this is not encoded in the files.

## Intake observations

- `obj_2_COMPOUND_3.stl`: 146.4500 x 68.4500 x 5.2000; one watertight connected shell after merging duplicate STL vertices. Likely cover/top by size, but filename is unlabeled. Mesh volume 15521.49 (old `上盖.STEP` 11621.688), so it is not safe to assume identical geometry from the matching envelope.
- `obj_1_COMPOUND_1.stl`: 149.5000 x 72.0000 x 17.9000; one watertight connected shell. Likely base/bottom by size. Old `底壳.STEP` is 149.5 x 71.5 x 17.9 and volume 31716.813; new mesh volume 31749.39.
- `obj_3_COMPOUND_4.stl`: 20.8909 x 8.0000 x 2.3000; one watertight connected shell. Separate unlabeled feature/part; not the old 7.0 x 4.3 x 7.0 button by envelope.

The two large STL global coordinate ranges are disjoint (`obj_2` Y=47.7625..116.2125; `obj_1` Y=138.1987..210.1987), with a ~21.99 coordinate gap. No assembly transform is encoded; do not combine STL bboxes into an assembled size. The prior old STEP note that the top needed Y+16.7 for assembly cannot be verified or transferred from this package.

Previews are generated from the supplied mesh only; they are inspection aids, not design geometry.
