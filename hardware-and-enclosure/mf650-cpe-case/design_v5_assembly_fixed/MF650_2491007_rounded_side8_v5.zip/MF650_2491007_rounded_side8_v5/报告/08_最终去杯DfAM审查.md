# 08 按键延长件：最终去杯 DfAM 审查

审查对象为本包 `打印件_STL/08_button_extender_from_aux.stl`。其 SHA-256 必须为
`28ea00ef126f35e2f1cb499fbb2d17e69cb42f087aeb4a6f9b1190e2d2a5297a`，文件大小为 94,384 B。

实际运行 [dfam-check](https://github.com/earthtojake/text-to-cad/tree/main/skills/dfam-check) 的 `dfam_tool.py`：

```text
dfam_tool.py measure <final-08.stl> --angle-limit 30
dfam_tool.py measure <final-08.stl> --samples 10000 --angle-limit 30
dfam_tool.py orientations <final-08.stl> --angle-limit 30
```

最终 STL 是 1 个 watertight 实体，单位尺度正常。默认测量和 10,000 样本请求（本件受 1,886 面限制）均得到：

- 最小抽样壁厚：**1.200 mm**
- p05 抽样壁厚：**1.200 mm**
- 当前朝向低角度朝下面积：36.31 mm²（11.8%）
- 六轴候选中 `flip_180_x` 最低：28.19 mm²（9.1%），构建高度 10.70 mm。

方向候选不等于实际切片、支撑或材料保证。用户尚未指定材料、机器、层高、支撑和后处理；这些仍需在试样和实际切片中确认。

随包 JSON 是本最终去杯 STL 的默认/高样本/方向测量数据。包中没有历史有杯版本的测量数据。
