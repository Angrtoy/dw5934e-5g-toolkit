# MF650 2491007 圆角侧八天线加厚壳 v5（密集格栅与机械捕获按键）

## 先打印什么

所有 STL 均为 **mm、100% 比例**。整套外壳只打印 `打印件_STL/` 中带 `01_` 至 `09_` 前缀的 **9 件**；SMA 试片是位于 `试片_SMA孔位/` 的明确例外。`工程/` 和 `参考模型_勿打印/` 下的文件均不可切片。v4 用户应更换 `08_button_extender_from_aux.stl`；其余八件与验收版 v4 字节相同。

尺寸以最终 STL 实际包围盒为准：前面板为 **160×90 mm**；含两端连接块的主体为约 **161×90×39.6 mm**（该厚度为前/后壳包络，不含按钮外触面突出）；底座足板为 **100×85 mm**。源顶/底壳的 **19.6 mm** 是本次数字登记装配高度，**不是实物合盖厚度测量值**。

建议先打印 `试片_SMA孔位/sma_hole_fit_coupon.stl`，以真实 SMA 接头检查 Ø6.4–6.8 mm 试孔，再决定是否直接使用本设计的 Ø6.6 mm 侧孔。主件适合先做无电子件的干装和低填充试装；含锂电池时不可在无看护或异常发热状态下充电。

各件均按 **mm / 100%** 导入，禁止缩放；每件应单独放到打印平台并按其受力面、可见面和支撑需求选择合适朝向。本包**未进行实际切片、支撑或打印参数验证**。

## 装配顺序

1. `01_main_chassis.stl` 主体已经包含原底壳的功能框，**不再另装一套底壳**。先进行空壳试装，并装入可达位置的 M3 螺母。
2. 如需立式安装，在 `03_rear_cover_no_sma.stl` 尚未安装前固定 `09_dual_end_desk_base.stl`：在底座两条支撑外侧沿 Y 向装入 5.5 AF×2.4 mm M3 螺母；从新增后舱 Z≈−4 位置送入两颗 M3×16 螺钉，螺钉头抵主框内侧肩位，杆穿过主体和底座并拧入底座螺母。底座可绕 Z 旋转 180° 装到另一短端。
3. 先在 `04_left_side_antenna_panel_4x1.stl`、`05_right_side_antenna_panel_4x1.stl` 安装 SMA 并预留接线空间，再将侧板固定。两条长边各 4 个、共 8 个 Ø6.6 mm、轴向 Y 的 SMA 孔；`03_rear_cover_no_sma.stl` 没有 SMA 孔。
4. 按源定位安装硬件和 `06_registered_source_top_feature_frame.stl`、`07_registered_source_dual_ear_button_plate.stl`。`02_front_bezel.stl` 尚未安装时，从前方/外侧放入 `08_button_extender_from_aux.stl`；然后下落前盖，使 Ø6.2 驱动头穿过 Ø6.5 导向。其 Ø8 内法兰留在前盖内侧，防止向外拉脱。**打印按钮本身不带回弹机构，回弹需要设备原开关提供；实际按压行程、回弹和电气触发仍需装机确认。**07 的全行程横向偏移接近 0.1 mm 时已有轻微擦碰边界，试装时应确认顺滑回弹。
5. 最后安装 `03_rear_cover_no_sma.stl`，关闭前检查不会夹住任何接线。

## 五金与假设

- 壳、前后盖、侧板、底座：常规 M3 螺钉；底座固定链指定 M3×16、头 Ø5.5×3 mm 代理与 5.5 AF×2.4 mm 螺母。
- SMA 仅依商家提供的 1/4-36 UNS / 约 6 mm 螺纹信息建模。设计孔 Ø6.6；数字占位为 Ø6.5×12 尾段、Ø10 垫圈、8 AF 螺母，**并非实际 SMA、线缆弯曲半径或 PCB 的适配保证**。
- 天线图的橙色杆仅是 Ø8×100 mm 外形假设，安装于接头肩部外约 5 mm、向侧外/向上各 45°；不代表实际天线。

## 已完成的数字验证与边界

`报告/cad_validation.json` 合并记录了源 STL 的定位登记、9 件单一 watertight 体、全部 36 对静态关系、104 个前格栅孔从外至内的连续路径、源上下盖/装配件干涉、8 侧孔尾段空间、侧 M3 螺母装入、前盖压脚、上盖取出、按钮从前方放入及前盖下落的顺序路径、+Z 捕获、07 滑片的源上盖止挡及受限按压链、底座双端姿态、M3 夹持链、已识别原端口通路及天线外形占位检查。前盖的实际落座检查为 −0.100 mm：该姿态下各静态关系为零交叠，源上盖仍可 +0.200 mm 上移而不碰。

`报告/v4_unchanged_parts.json` 证明除 `08_button_extender_from_aux.stl` 外的八个最终 STL 与 v4 字节相同。最终 08 已实际使用 [`dfam-check`](https://github.com/earthtojake/text-to-cad/tree/main/skills/dfam-check) 的 `dfam_tool.py measure`（默认和 10,000 样本请求）及 `orientations` 在最终 STL 上复测：单一 watertight 实体，抽样最小壁厚和 p05 均为 **1.200 mm**。详见包内 `报告/08_最终去杯DfAM审查.md`；包中不含历史“有杯”08 的薄环测量。

这些是数字几何/空间验证；没有 PCB、电池、真实 USB 插头、实际 SMA、线缆、开关或天线重心实体。热、锂电安全、RF、充电、实际按键力/行程、实体装配与稳定性均未验证，必须由实际试装确认。

## 工程、来源与许可

`工程/design_v5_assembly_fixed/` 中的生成入口顺序为：

```text
build_mf650_2491007.py
→ validate_final.py
→ validate_base.py
→ render_vtk.py
```

工程脚本以相对父目录读取 `工程/source_revision_2491007/models/` 中的三个源 STL；解压后该路径已完整保留。生成需要 Python、CadQuery/OCP、trimesh、manifold3d 与 VTK。`参考模型_勿打印/front_bezel_reference.step` 不含最终 STL 的网格并入压脚，只可作新增几何参考，不能替代最终 `front_bezel.stl`。

原模型：小猪猪 `@user_2427993088`，MakerWorld 2491007，CC BY-NC-SA 4.0，二创自“滴滴”。再发布时必须保留署名、非商业及相同方式共享限制。更多来源记录见 `工程/source_revision_2491007/README.md`。
